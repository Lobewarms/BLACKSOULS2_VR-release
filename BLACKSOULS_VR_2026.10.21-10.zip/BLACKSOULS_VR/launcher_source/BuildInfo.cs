using System.Reflection;
[assembly: AssemblyTitle("BLACK SOULS II VR Launcher")]
[assembly: AssemblyProduct("BLACK SOULS II VR")]
[assembly: AssemblyVersion("2026.10.21.10")]
[assembly: AssemblyFileVersion("2026.10.21.10")]
namespace BlacksoulsVR { static class BuildInfo { public const string Version = "2026.10.21-10"; } }
