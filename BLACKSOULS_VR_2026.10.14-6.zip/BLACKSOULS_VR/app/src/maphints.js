// Corrections for maps whose 2D layout cannot tell what is up.
//  sideView: the map is a tower drawn from the side, climbed by ledges and stairs. Heights come from its
//            fall events (a fall that carries the player n rows down lands n tiles lower) and every cell a
//            fall passes through is open air (mapmesh.js).
//  floors:   hand-made heights, rectangles of walkable cells [x0, y0, x1, y1, heightAtNorthEdge,
//            heightAtSouthEdge] in tiles, sloping north to south between the two. Later ones win.
//  flatPictures: tile ids of small upright pictures that keep their 2D facing (one plane across the cell, seen
//            from the front and the back) instead of turning to the viewer
//  lips:     cells that cannot be walked on drawn as a low ledge [x0, y0, x1, y1, height above the higher floor
//            beside it, in tiles] instead of the block they would otherwise be (their own art on top)
//  openFights: fights here never close the map (no boss arena): the exits stay open and everyone stays in sight
//  terraces: a town of terraces and flat roofs climbed by stairs drawn as floor tiles (A5) - { stairs: [A5
//            tile numbers of flights drawn from the front], sideStairs: [... drawn side-on] }: those stairs are
//            climbs, not floor, and places only join into one level where the original lets you walk between
//            them (a roof's edge stops you): each roof / terrace is its own level, as high above the street as the
//            wall drawn under it (mapmesh.js)
//  hideArt:  upper-layer pieces left out of the 3D view [x0, y0, x1, y1, [tile ids]] - the foot of a staircase drawn up a
//            wall, sticking out in front of it: stood up, it was planks hanging in the air (the rest stays on the wall;
//            what can be walked on is as in the original)
//  massBackdrop: blocks of things piled up on the floor (heaps of books) show the nearest wall's art behind them on
//            their faces instead of the floor's
//  caps:     walls that are the front of a raised floor [x0, y0, x1, y1, top in tiles]: their top no higher than that
//  props:    things standing on the floor in a row along a wall's foot [x0, y0, x1, y1] (crates, barrels, pots): each
//            stands as its own picture instead of the cells joining into a block of the wall (their floor drawn
//            round them on its faces)
//  openSky:  the background picture is the sky round the map and the land far below (병든 시계탑 3: towers high over the town at
//            night): what the map leaves untiled or draws with a clear tile (its bridge nobody can see, the drops beside it) is open
//            air, every drop going down as far as the deepest, with no ground drawn under it (mapmesh.js)
//  wallCap:  walls stand as tall as their drawing, up to this many tiles (otherwise 6): towers drawn whole from the front
//  doorTops: the top half of a door drawn two rows tall in a facade [[x, y], ...] (its bottom row is the way in): built as part of
//            that wall, drawn as itself, so the door is a doorway with the wall going on above it - not a slot up to the top
//  abyss:    a drop the map draws black beside a walkway [x0, y0, x1, y1, depth in tiles]: left open instead of
//            walled in like the black ceiling - the floor's edge goes down into the dark with a small curb along
//            it, and a wall face drawn there right under a floor hangs below that floor's edge (mapmesh.js)
const LIBRARY_GALLERY = [[11, 11, 32, 14, 2, 2], [13, 15, 15, 17, 2, 0], [28, 15, 30, 17, 2, 0]];
const LIBRARY_FRONT = [[11, 15, 32, 17, 2]];      // (the gallery's front: no higher than the gallery)
export const MAP_HINTS = {
  1: { sideView: true },     // 추락의 방: ledges and stairs up a brick tower, falls down its shaft
  // 병든 시계탑 (the hall): the crates, barrels and pots under the staircase drawn on the back wall, and the
  // staircase's foot - they stood as a block with the plank floor round them on its faces
  24: { props: [[13, 13, 21, 14]], hideArt: [[13, 13, 16, 14, [132, 133, 140, 141, 148, 149]]] },
  // 병든 시계탑 3: two towers over the town at night, a walkway along their fronts and between them a bridge nobody can see
  // (row 14 - a step off it either side is a fall): the background lay as a plane just under the walkways, so no drop looked like one.
  // The towers stand as tall as drawn (the clock whole, not cut at 6 tiles) and the two black doors under the clock are doorways
  159: { openSky: true, wallCap: 14, doorTops: [[41, 12], [52, 12]] },
  // 소녀의 악몽: the girls in their nightmare forms (도마뱀 빌, 도도, 그리피, 시부치...: twelve fights) roam and chase -
  // they can be left behind through the exits (the user's choice; the nightmare's later bosses keep their arenas)
  49: { openFights: true },
  134: { flatPictures: [912] },   // 홍성 프릿셀 6: the croquet hoops - walked through in order to open a door
  // 홍성 프릿셀 7 (개방형 홀), behind the croquet door: the bridge the axes swing across, over the dark the hall's
  // foundation drops into - its sides small curbs, not walls, so the axes are seen coming
  142: { abyss: [[3, 8, 10, 50, 6], [14, 8, 21, 50, 6]] },
  // 도서관의 꿈 and the libraries built on it (옥스・워드 대학교 ２ BOSS, 하얀 성시 ７－１１ BOSS and its １): the back of the
  // hall is a gallery two tiles up (its front the bookshelves of rows 15-16, its railing row 14), reached by the
  // stairs at x13-15 and x28-30 - all of it lay flat, the stairs drawn on the floor, the white door up there
  101: { floors: LIBRARY_GALLERY, caps: LIBRARY_FRONT, massBackdrop: true },
  154: { floors: LIBRARY_GALLERY, caps: LIBRARY_FRONT, massBackdrop: true },
  372: { floors: LIBRARY_GALLERY, caps: LIBRARY_FRONT, massBackdrop: true },
  373: { floors: LIBRARY_GALLERY, caps: LIBRARY_FRONT },
  // 하얀 성시 ７－１１ BOSS ２ (그랑・기뇰's theatre): the stage (rows 6-10) stands 0.9 m above the house; its front
  // row, kept off in the original by an invisible tile and drawn as more stage, is the stage's lip - not a wall
  // between the stage and the house
  374: { floors: [[3, 6, 31, 10, 0.6, 0.6]], lips: [[3, 11, 31, 11, 0.1]] },
  // 하얀 성시 ７ (윈터벨): white houses with flat roofs and terraces, stairs between them drawn as A5 floor tiles -
  // all of it one flat level otherwise (the stairs joined every level)
  353: { terraces: { stairs: [8, 9, 10, 16, 17, 18], sideStairs: [3, 4, 11, 12, 13, 22, 23, 30, 31, 37, 38, 43, 44] } },
  // 하얀 성시 ７－３: the same town along the shore (the street over the wall west of the garden, stairs up to the arches)
  356: { terraces: { stairs: [8, 9, 10, 16, 17, 18], sideStairs: [3, 4, 11, 12, 13, 22, 23, 30, 31, 37, 38, 43, 44] } },
};

export function floorHints(mapId) { return MAP_HINTS[mapId]?.floors || null; }
export function lipHints(mapId) { return MAP_HINTS[mapId]?.lips || null; }
export function abyssHints(mapId) { return MAP_HINTS[mapId]?.abyss || null; }
export function openFights(mapId) { return !!MAP_HINTS[mapId]?.openFights; }
export function isSideView(mapId) { return !!MAP_HINTS[mapId]?.sideView; }
export function flatPictures(mapId) { return MAP_HINTS[mapId]?.flatPictures || null; }
export function terraceHints(mapId) { return MAP_HINTS[mapId]?.terraces || null; }
export function propHints(mapId) { return MAP_HINTS[mapId]?.props || null; }
export function hideArtHints(mapId) { return MAP_HINTS[mapId]?.hideArt || null; }
export function capHints(mapId) { return MAP_HINTS[mapId]?.caps || null; }
export function massBackdrop(mapId) { return !!MAP_HINTS[mapId]?.massBackdrop; }
export function openSky(mapId) { return !!MAP_HINTS[mapId]?.openSky; }
export function wallCap(mapId) { return MAP_HINTS[mapId]?.wallCap || 0; }
export function doorTops(mapId) { return MAP_HINTS[mapId]?.doorTops || null; }

// Background pictures (parallaxes) not wrapped round the sky (sky.js) - the user's choice: 루트위지 시가지's stone
// street and 도지슨교's town under clouds, the book of 도서관의 꿈 (also 하얀 성시 ７－１１ BOSS), cave rock
// (도살장), flesh (무한음식), the clock face (병든 시계탑 1)
export const NOT_SKY = new Set(['rad2', 'rad3', 'book02', 'firecave', 'monster39', 'ijigen']);
export function skyPicture(name) { return !!name && !NOT_SKY.has(name); }
// ... and those that are the whole background in 2D, with no horizon - a sky, space, a texture (gears, the mental
// world's glass / wood / colour blots, blue flames): they cover the sky overhead too, not only a band round the
// horizon with plain colour above (sea views, the moon, towns and mountains far off keep their horizon at eye level)
export const SKY_ALL_OVER = new Set(['StarlitSky', 'CloudySky2', 'BlueSky', '64380033_p2_master1200', 'publicdomainq-0021126ule',
  'Cave3', '精神世界', '精神世界２', '精神世界３']);
export function skyAllOver(name) { return SKY_ALL_OVER.has(name); }
